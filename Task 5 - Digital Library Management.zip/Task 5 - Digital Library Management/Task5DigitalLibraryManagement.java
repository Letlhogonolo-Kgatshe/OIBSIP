
import javax.swing.JOptionPane;

public class Task5DigitalLibraryManagement {
    public static void main(String[] args) {
        // Arrays to store users and books
        String[] users = new String[10];
        int[] userIds = new int[10];
        String[] books = new String[10];
        boolean[] bookIssued = new boolean[10];

        // Counter to keep track of how many users and books are stored
        int userCount = 0;
        int bookCount = 0;

        while (true) {
            // Display the main menu
            String input = JOptionPane.showInputDialog("Welcome to Digital Library Management\n" +
                    "1) Admin\n" +
                    "2) User\n" +
                    "3) Exit");

            int choice = Integer.parseInt(input); // Convert the input to an integer

            // Main menu options
            if (choice == 1) {
                // Admin Menu
                String adminInput = JOptionPane.showInputDialog("Admin Menu\n" +
                        "1) Add User\n" +
                        "2) Remove User\n" +
                        "3) Add Book\n" +
                        "4) Remove Book\n" +
                        "5) List Books\n" +
                        "6) Back to Main Menu");

                int adminChoice = Integer.parseInt(adminInput); // Convert the input to an integer

                if (adminChoice == 1) {
                    // Add a new user
                    String username = JOptionPane.showInputDialog("Enter Username:");
                    String userIdInput = JOptionPane.showInputDialog("Enter User ID:");

                    int userId = Integer.parseInt(userIdInput); // Convert the user ID to an integer

                    // Store the user data
                    users[userCount] = username;
                    userIds[userCount] = userId;
                    userCount++;

                    JOptionPane.showMessageDialog(null, "User added: " + username);
                } else if (adminChoice == 2) {
                    // Remove a user
                    String userIdInput = JOptionPane.showInputDialog("Enter User ID to Remove:");
                    int userId = Integer.parseInt(userIdInput); // Convert the user ID to an integer

                    // Find and remove the user
                    for (int i = 0; i < userCount; i++) {
                        if (userIds[i] == userId) {
                            users[i] = null; // Remove user by setting it to null
                            userIds[i] = 0; // Reset user ID
                            JOptionPane.showMessageDialog(null, "User removed: " + userId);
                            break;
                        }
                    }
                } else if (adminChoice == 3) {
                    // Add a new book
                    String bookTitle = JOptionPane.showInputDialog("Enter Book Title:");
                    String bookAuthor = JOptionPane.showInputDialog("Enter Book Author:");

                    // Store the book data
                    books[bookCount] = bookTitle + " by " + bookAuthor;
                    bookIssued[bookCount] = false; // Mark the book as not issued
                    bookCount++;

                    JOptionPane.showMessageDialog(null, "Book added: " + bookTitle);
                } else if (adminChoice == 4) {
                    // Remove a book
                    String bookTitle = JOptionPane.showInputDialog("Enter Book Title to Remove:");

                    // Find and remove the book
                    for (int i = 0; i < bookCount; i++) {
                        if (books[i] != null && books[i].contains(bookTitle)) {
                            books[i] = null; // Remove book by setting it to null
                            bookIssued[i] = false; // Reset issued status
                            JOptionPane.showMessageDialog(null, "Book removed: " + bookTitle);
                            break;
                        }
                    }
                } else if (adminChoice == 5) {
                    // List all books
                    String bookList = "Books in the library:\n";
                    for (int i = 0; i < bookCount; i++) {
                        if (books[i] != null) {
                            bookList += books[i] + " - " + (bookIssued[i] ? "Issued" : "Available") + "\n";
                        }
                    }
                    JOptionPane.showMessageDialog(null, bookList);
                }
            } else if (choice == 2) {
                // User Menu
                String userInput = JOptionPane.showInputDialog("User Menu\n" +
                        "1) Browse Books\n" +
                        "2) Issue Book\n" +
                        "3) Return Book\n" +
                        "4) Back to Main Menu");

                int userChoice = Integer.parseInt(userInput); // Convert the input to an integer

                if (userChoice == 1) {
                    // Browse available books
                    String availableBooks = "Available books:\n";
                    for (int i = 0; i < bookCount; i++) {
                        if (books[i] != null && !bookIssued[i]) {
                            availableBooks += books[i] + "\n";
                        }
                    }
                    JOptionPane.showMessageDialog(null, availableBooks);
                } else if (userChoice == 2) {
                    // Issue a book
                    String bookTitle = JOptionPane.showInputDialog("Enter Book Title to Issue:");

                    // Find and issue the book
                    for (int i = 0; i < bookCount; i++) {
                        if (books[i] != null && books[i].contains(bookTitle) && !bookIssued[i]) {
                            bookIssued[i] = true; // Mark the book as issued
                            JOptionPane.showMessageDialog(null, "Book issued: " + bookTitle);
                            break;
                        }
                    }
                } else if (userChoice == 3) {
                    // Return a book
                    String bookTitle = JOptionPane.showInputDialog("Enter Book Title to Return:");

                    // Find and return the book
                    for (int i = 0; i < bookCount; i++) {
                        if (books[i] != null && books[i].contains(bookTitle) && bookIssued[i]) {
                            bookIssued[i] = false; // Mark the book as returned
                            JOptionPane.showMessageDialog(null, "Book returned: " + bookTitle);
                            break;
                        }
                    }
                }
            } else if (choice == 3) {
                // Exit the program
                System.exit(0);
            } else {
                JOptionPane.showMessageDialog(null, "Invalid choice! Please try again.");
            }
        }
    }
}
