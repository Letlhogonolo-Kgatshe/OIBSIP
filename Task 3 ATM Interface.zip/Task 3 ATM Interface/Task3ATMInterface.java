import javax.swing.JOptionPane;

public class Task3ATMInterface {

    public static void main(String[] args) {
        ATM atm = new ATM();

        while (true) {
            int userID = promptForInteger("Please enter User ID");
            int userPin = promptForInteger("Please enter User PIN");

            if (userID == 0 && userPin == 12345) {
                boolean continueOperations = true;
                while (continueOperations) {
                    try {
                        int option = atm.getOption();
                        switch (option) {
                            case 1:
                                atm.withdraw();
                                break;
                            case 2:
                                atm.deposit();
                                break;
                            case 3:
                                atm.checkBalance();
                                break;
                            case 4:
                                atm.TransactionHistory();
                                break;
                            case 5:
                                atm.Transfer();
                                break;
                            case 6:
                                atm.Quit();
                                continueOperations = false; // Exit the loop after quitting
                                break;
                            case -1:
                                JOptionPane.showMessageDialog(null, "Operation cancelled by the user.");
                                break;
                            default:
                                JOptionPane.showMessageDialog(null, "Invalid entry");
                        }

                        if (continueOperations) {
                            int confirm = JOptionPane.showConfirmDialog(null, "Do you want to perform another operation?");
                            if (confirm != JOptionPane.YES_OPTION) {
                                JOptionPane.showMessageDialog(null, "Thank you for using the ATM. Goodbye!");
                                continueOperations = false; // Exit the operation loop
                            }
                        }

                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, "Invalid entry");
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "Incorrect userID or PIN");
            }
        }
    }

    // Method to prompt for an integer input
    private static int promptForInteger(String message) {
        while (true) {
            try {
                String input = JOptionPane.showInputDialog(null, message);
                if (input == null) {  // Handle case where user cancels the input
                    JOptionPane.showMessageDialog(null, "Operation cancelled by the user.");
                    System.exit(0);
                }
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number.");
            }
        }
    }
}
