import javax.swing.JOptionPane;

public class ATM {
    private static int balance = 500;
    private String transactionHistory = "";
    public void deposit() {
        try {
            String input = JOptionPane.showInputDialog(null, 
                "Please enter the amount to deposit into the account (no more than R1000 at a time):");

            if (input == null) {
                // Handle cancel or close
                JOptionPane.showMessageDialog(null, "Deposit operation cancelled.");
                return; // Exit the method
            }

            int depositAmount = Integer.parseInt(input);
            
            if (depositAmount > 0 && depositAmount <= 1000) {
                balance += depositAmount;
                transactionHistory += "Deposited: R" + depositAmount + "\n";
                JOptionPane.showMessageDialog(null, "Deposit successful! New balance: R" + balance);
            } else {
                JOptionPane.showMessageDialog(null, "Invalid deposit amount. Must be between 1 and 1000.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid entry");
        }
    }

    public void withdraw() {
        try {
            String input = JOptionPane.showInputDialog(null, 
                "Please enter the amount to withdraw from the account:");

            if (input == null) {
                // Handle cancel or close
                JOptionPane.showMessageDialog(null, "Withdrawal operation cancelled.");
                return; // Exit the method
            }

            int withdrawAmount = Integer.parseInt(input);
            
            if (withdrawAmount > 0 && withdrawAmount <= balance) {
                balance -= withdrawAmount;
                transactionHistory += "Withdrawn: R" + withdrawAmount + "\n";
                JOptionPane.showMessageDialog(null, "Withdrawal successful! New balance: R" + balance);
            } else if (withdrawAmount > balance) {
                JOptionPane.showMessageDialog(null, "Withdrawal amount exceeds balance. Balance: R" + balance);
            } else {
                JOptionPane.showMessageDialog(null, "Invalid withdrawal amount.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid entry");
        }
    }

    public void checkBalance() {
        JOptionPane.showMessageDialog(null, "Current balance: R" + balance);
    }

    public int getOption() {
        try {
            String input = JOptionPane.showInputDialog(null,
                "Please select one of the available options below:\n" +
                "1) Withdraw Amount\n" +
                "2) Deposit Amount\n" +
                "3) Check Balance\n" +
                "4) Transaction History\n" +
                "5) Transfer\n" +
                "6) Quit\n" );
                ;

            if (input == null) {
                // Handle cancel or close
                return -1; // Return an invalid option to indicate cancellation
            }

            return Integer.parseInt(input);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid entry");
            return -1; // Return an invalid option to trigger the default case
        }
    }

    public static int getBalance() {
        return balance;
    }

    public static void setBalance(int balance) {
        ATM.balance = balance;
    }

    public void TransactionHistory() 
    {
        JOptionPane.showMessageDialog(null, "Transaction History:\n" + transactionHistory);
    }

    public void Transfer() 
    {
        String accountStr = JOptionPane.showInputDialog(null, "Enter account number to transfer to");
        String amountStr = JOptionPane.showInputDialog(null, "Enter amount to transfer");
        double amount = Double.parseDouble(amountStr);
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            transactionHistory += "Transferred: R" + amount + " to account " + accountStr + "\n";
            JOptionPane.showMessageDialog(null, "Transfer successful. New balance: R" + balance);
        } else {
            JOptionPane.showMessageDialog(null, "Invalid amount or insufficient funds");
        }
    }

    public void Quit() {
        JOptionPane.showMessageDialog(null, "Thank you for using the ATM. Goodbye!");
        System.exit(0);
        }
}