    import javax.swing.JOptionPane;

public class Task2NumberGuessingGame {
    // Random number generator and guessing game
    public static void main(String[] args) 
    {
        boolean Yes = true;

        while (true) 
        {       
        int gen = (int) (Math.random() * 100);  //Generated numbet between 0and 100
        int attempts = 0;   //Counter for the number of attempts by user
        boolean valid = false;  // Flag to see if the correct number was guessed

            while (!valid)
                {
                    try //Try catch for incorrect number exception and invalid entry
                    {
                        String input = JOptionPane.showInputDialog(null, "Please enter a number between 0 and 99 (or Cancel to quit)");
                    
                        if (input == null) // Handle Cancel button
                        { 
                            JOptionPane.showMessageDialog(null, "Game cancelled by the user.");
                            valid = true; // Exit the current game round
                            Yes = false; // Exit the main loop
                            break;
                        }
                            int guess = Integer.parseInt(input);
                            attempts +=1;
                            if (guess < gen) 
                            {
                                JOptionPane.showMessageDialog(null, "Number too low \n Guess again");
                            }
                            else if (guess > gen)
                            {
                                JOptionPane.showMessageDialog(null, "Number too hign \n Guess again");
                            }
                            else if (guess == gen)
                            {
                                JOptionPane.showMessageDialog(null, "Correct \n "+ attempts + " attempts \n"+ (10- attempts) + " Points Scored");
                                valid = true;
                            }
                            
                            if (attempts >= 10) // Limit on the number of attempts allowed
                            {
                                JOptionPane.showMessageDialog(null, "You have exceeded the number of allowed attempts \n"+attempts + " attempts \n Game Over");
                                valid = true;
                            }
                    }
                    catch (NumberFormatException exception)
                    {
                          JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.");
                    }
                }

                int confirm = JOptionPane.showConfirmDialog(null, "Do you want to play again ?");   //Pop-up to ask if user wants to play
                Yes = (confirm == JOptionPane.YES_OPTION);  // Captures user answer YES or NO

                if (!Yes)   // If the user decides to select no option
                {
                    JOptionPane.showMessageDialog(null,"Thank You for playing");
                    break;
                }
        }
    }
}


