import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Task1OnlineReservationSystem {

    static ArrayList<User> users = new ArrayList<>(); 
    static ArrayList<Reservation> reservations = new ArrayList<>();
    
    public static void main(String[] args) {
        while (true) {
            int option = Integer.parseInt(JOptionPane.showInputDialog(null, 
                "Please select an option:\n1) Register\n2) Log in\n3) Exit"));
            switch (option) {
                case 1:
                    registerUser();
                    break;
                case 2:
                    loginUser();
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "Thank you for using the system. Goodbye!");
                    System.exit(0);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option. Please try again.");
            }
        }
    }
    
    // Register User Method
    public static void registerUser() {
        String username = JOptionPane.showInputDialog(null, "Enter your username:");
        String password = JOptionPane.showInputDialog(null, "Enter your password:");
        
        users.add(new User(username, password));
        JOptionPane.showMessageDialog(null, "Registration successful! You can now log in.");
    }
    
    // Login User Method
    public static void loginUser() {
        String username = JOptionPane.showInputDialog(null, "Enter your username:");
        String password = JOptionPane.showInputDialog(null, "Enter your password:");
        
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                JOptionPane.showMessageDialog(null, "Login successful!");
                userMenu();
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Login failed. Incorrect username or password.");
    }
    
    // User Menu after login
    public static void userMenu() {
        while (true) {
            int option = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Please select an option:\n1) Make a Reservation\n2) Cancel a Reservation\n3) Log Out"));
            switch (option) {
                case 1:
                    makeReservation();
                    break;
                case 2:
                    cancelReservation();
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "Logged out successfully.");
                    return;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option. Please try again.");
            }
        }
    }

    // Method to make a reservation
    public static void makeReservation() {
        String trainNumber = JOptionPane.showInputDialog(null, "Enter Train Number:");
        String trainName = JOptionPane.showInputDialog(null, "Enter Train Name:");
        String journeyDate = JOptionPane.showInputDialog(null, "Enter Journey Date:");
        String from = JOptionPane.showInputDialog(null, "Enter Departure Location:");
        String to = JOptionPane.showInputDialog(null, "Enter Destination:");
        String classType = JOptionPane.showInputDialog(null, "Enter Class Type:");
        
        Reservation reservation = new Reservation(trainNumber, trainName, journeyDate, from, to, classType);
        reservations.add(reservation);
        
        JOptionPane.showMessageDialog(null, "Reservation made successfully! Your PNR is: " + reservation.getPnr());
    }

    // Method to cancel a reservation
    public static void cancelReservation() {
        String pnr = JOptionPane.showInputDialog(null, "Enter PNR to cancel:");
        boolean removed = false;

        for (int i = 0; i < reservations.size(); i++) {
            if (reservations.get(i).getPnr().equals(pnr)) {
                reservations.remove(i);
                removed = true;
                break;
            }
        }

        if (removed) {
            JOptionPane.showMessageDialog(null, "Reservation canceled successfully.");
        } else {
            JOptionPane.showMessageDialog(null, "Reservation not found.");
        }
    }
}