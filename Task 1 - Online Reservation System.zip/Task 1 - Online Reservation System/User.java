import java.util.ArrayList;

public class User {
    private String username;
    private String password;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}

// Reservation Class Definition
class Reservation {
    private static int counter = 1;
    private String pnr;
    private String trainNumber;
    private String trainName;
    private String journeyDate;
    private String from;
    private String to;
    private String classType;

    public Reservation(String trainNumber, String trainName, String journeyDate, String from, String to, String classType) {
        this.pnr = "PNR" + (counter++);
        this.trainNumber = trainNumber;
        this.trainName = trainName;
        this.journeyDate = journeyDate;
        this.from = from;
        this.to = to;
        this.classType = classType;
    }

    public String getPnr() {
        return pnr;
    }
}