import java.util.ArrayList;
import java.util.Scanner;
public class Task4OnlineExamination {

    static ArrayList<ExamUser> users = new ArrayList<>();
    static ArrayList<Question> questions = new ArrayList<>();
    static ExamUser currentUser = null;

    public static void main(String[] args) {
        setupSampleData(); // Setting up sample data for testing
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Please select an option:\n1) Log in\n2) Exit");
            int option = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (option) {
                case 1:
                    loginUser(scanner);
                    break;
                case 2:
                    System.out.println("Thank you for using the system. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    // User Login Method
    public static void loginUser(Scanner scanner) {
        System.out.print("Enter your username: ");
        String username = scanner.nextLine();
        System.out.print("Enter your password: ");
        String password = scanner.nextLine();

        for (ExamUser user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                currentUser = user;
                System.out.println("Login successful!");
                userMenu(scanner);
                return;
            }
        }
        System.out.println("Login failed. Incorrect username or password.");
    }

    // User Menu after login
    public static void userMenu(Scanner scanner) {
        while (true) {
            System.out.println("Please select an option:\n1) Update Profile\n2) Change Password\n3) Start Exam\n4) Log Out");
            int option = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (option) {
                case 1:
                    updateProfile(scanner);
                    break;
                case 2:
                    changePassword(scanner);
                    break;
                case 3:
                    startExam(scanner);
                    break;
                case 4:
                    currentUser = null;
                    System.out.println("Logged out successfully.");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    // Update Profile Method
    public static void updateProfile(Scanner scanner) {
        System.out.print("Enter new username: ");
        String newUsername = scanner.nextLine();
        currentUser.setUsername(newUsername);
        System.out.println("Profile updated successfully.");
    }

    // Change Password Method
    public static void changePassword(Scanner scanner) {
        System.out.print("Enter new password: ");
        String newPassword = scanner.nextLine();
        currentUser.setPassword(newPassword);
        System.out.println("Password changed successfully.");
    }

    // Start Exam Method
    public static void startExam(Scanner scanner) {
        System.out.println("Exam started! Answer the following questions:");
        int correctAnswers = 0;
        
        for (Question question : questions) {
            System.out.println(question.getQuestion());
            String[] options = question.getOptions();
            for (int i = 0; i < options.length; i++) {
                System.out.println((i + 1) + ") " + options[i]);
            }
            int answer = scanner.nextInt();
            if (question.isCorrect(answer - 1)) {
                correctAnswers++;
            }
        }

        System.out.println("Exam finished! You got " + correctAnswers + " out of " + questions.size() + " correct.");
    }


    // Setup Sample Data (Users and Questions)
    public static void setupSampleData() {
        users.add(new ExamUser("user1", "password1"));
        users.add(new ExamUser("user2", "password2"));

        String[] options1 = {"Option A", "Option B", "Option C", "Option D"};
        questions.add(new Question("What is the capital of France?", options1, 0)); // Correct: Option A

        String[] options2 = {"2", "3", "4", "5"};
        questions.add(new Question("What is 2 + 2?", options2, 2)); // Correct: 4
    }
}